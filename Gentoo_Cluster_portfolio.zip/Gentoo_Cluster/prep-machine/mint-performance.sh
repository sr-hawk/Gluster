#!/usr/bin/env bash
# Linux Mint Cinnamon 22.3 — automated performance tweaks (SSD laptop).
# Applies: fstab noatime, /tmp on RAM (tmp.mount), thumbnail cache -> /tmp
# (the "caching trick" via login autostart), swappiness=20, vfs_cache_pressure=50,
# grub verbose boot (removes "quiet splash").
#
# Usage: bash mint-performance.sh        (will re-exec itself under sudo)
#
# Safe to re-run. A reboot is recommended after first run.

set -euo pipefail

# ---- 1. Elevate --------------------------------------------------------------
if [[ $EUID -ne 0 ]]; then
    exec sudo -E bash "$0" "$@"
fi

# ---- 2. Resolve the non-root target user for user-scoped bits ----------------
TARGET_USER="${SUDO_USER:-}"
if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
    TARGET_USER="$(logname 2>/dev/null || true)"
fi
if [[ -z "$TARGET_USER" || "$TARGET_USER" == "root" ]]; then
    echo "ERROR: could not determine the real user. Run as: sudo bash $0" >&2
    exit 1
fi
TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
TARGET_GROUP="$(id -gn "$TARGET_USER")"

log() { printf '[mint-perf] %s\n' "$*"; }

# ---- 3. fstab: noatime on SSD ------------------------------------------------
log "fstab: ensuring noatime..."
if grep -qE '(^|[[:space:]])noatime' /etc/fstab; then
    log "  already present — skipping."
elif grep -qE 'errors=remount-ro' /etc/fstab; then
    cp -a /etc/fstab "/etc/fstab.bak.$(date +%Y%m%d%H%M%S)"
    sed -i 's/ errors=remount-ro/ noatime,errors=remount-ro/' /etc/fstab
    log "  inserted noatime before errors=remount-ro."
else
    log "  WARNING: no errors=remount-ro line found; leaving fstab alone."
fi

# ---- 3b. grub: verbose boot (strip "quiet splash") ---------------------------
log "grub: enabling verbose boot..."
GRUB_FILE=/etc/default/grub
if [[ -f "$GRUB_FILE" ]]; then
    if grep -Eq '^GRUB_CMDLINE_LINUX_DEFAULT=".*(quiet|splash).*"' "$GRUB_FILE"; then
        cp -a "$GRUB_FILE" "${GRUB_FILE}.bak.$(date +%Y%m%d%H%M%S)"
        # Remove quiet and splash tokens (and any resulting double spaces) from the default cmdline.
        sed -i -E '
            /^GRUB_CMDLINE_LINUX_DEFAULT=/{
                s/\bquiet\b//g
                s/\bsplash\b//g
                s/  +/ /g
                s/" /"/
                s/ "/"/
            }
        ' "$GRUB_FILE"
        update-grub >/dev/null
        log "  stripped quiet/splash and ran update-grub."
    else
        log "  quiet/splash not present — skipping."
    fi
else
    log "  WARNING: $GRUB_FILE missing — skipping."
fi

# ---- 4. /tmp on RAM via systemd tmp.mount -----------------------------------
log "tmp.mount: enabling..."
if [[ -f /usr/share/systemd/tmp.mount ]]; then
    install -m 0644 /usr/share/systemd/tmp.mount /etc/systemd/system/tmp.mount
    systemctl enable tmp.mount >/dev/null
    log "  enabled (activates after reboot)."
else
    log "  WARNING: /usr/share/systemd/tmp.mount missing — skipping."
fi

# ---- 5. sysctl: swappiness + vfs_cache_pressure ------------------------------
log "sysctl: swappiness=20, vfs_cache_pressure=50..."
SYSCTL_FILE=/etc/sysctl.d/99-mint-performance.conf
cat > "$SYSCTL_FILE" <<'EOF'
# Managed by mint-performance.sh
# Decrease swap & cache usage to a more reasonable level
vm.swappiness=20
vm.vfs_cache_pressure=50
EOF
sysctl -p "$SYSCTL_FILE" >/dev/null
log "  applied live."

# ---- 6. Thumbnail cache -> /tmp (the caching trick) --------------------------
log "cacheupdate: installing for user '$TARGET_USER'..."

CACHEUPDATE_BIN="$TARGET_HOME/.local/bin/cacheupdate"
install -d -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0755 \
    "$TARGET_HOME/.local" "$TARGET_HOME/.local/bin"

cat > "$CACHEUPDATE_BIN" <<'EOF'
#!/usr/bin/env bash
# Re-point the thumbnail cache directories at /tmp (RAM, thanks to tmp.mount).
# Runs at every login because /tmp is wiped on reboot.
set -eu
TH="$HOME/.cache/thumbnails"
mkdir -p "$TH"
for d in fail large normal; do
    # Remove stale entry (dir, dead symlink, or live symlink) then recreate target in /tmp
    rm -rf -- "$TH/$d"
    mkdir -p "/tmp/$d"
    ln -sfn "/tmp/$d" "$TH/$d"
done
EOF
chmod 0755 "$CACHEUPDATE_BIN"
chown "$TARGET_USER:$TARGET_GROUP" "$CACHEUPDATE_BIN"

AUTOSTART_DIR="$TARGET_HOME/.config/autostart"
install -d -o "$TARGET_USER" -g "$TARGET_GROUP" -m 0755 \
    "$TARGET_HOME/.config" "$AUTOSTART_DIR"

AUTOSTART_DESKTOP="$AUTOSTART_DIR/cacheupdate.desktop"
cat > "$AUTOSTART_DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=Cache Update
Comment=Redirect thumbnail cache into /tmp (RAM) on every login
Exec=$CACHEUPDATE_BIN
X-GNOME-Autostart-enabled=true
NoDisplay=true
Terminal=false
EOF
chown "$TARGET_USER:$TARGET_GROUP" "$AUTOSTART_DESKTOP"
log "  installed $CACHEUPDATE_BIN and autostart entry."

# Run once now so the trick is active immediately.
sudo -u "$TARGET_USER" -H bash "$CACHEUPDATE_BIN"
log "  ran once for current session."

# ---- Done --------------------------------------------------------------------
cat <<EOF

[mint-perf] All performance tweaks applied.
  - fstab noatime
  - grub verbose boot (quiet splash removed)
  - /tmp on RAM (tmp.mount, active after reboot)
  - vm.swappiness=20, vm.vfs_cache_pressure=50 (live)
  - thumbnail cache symlinked to /tmp, cacheupdate installed at login

Please reboot to activate tmp.mount.
EOF
